# 2021chanllenge

Jeffery is a sophomore in NTU who loves to say trash talk and his dream is to be a coding monster. One day, Mazu appeared to him in a dream and said: "To be a coding monster, you have to stop saying XXXX." To turn a new leaf, Jeffery has to know what XXXX is and tells Mazu to help him be a coding monster.

Now, you, as a CSIE student, please help Jeffery find what XXXX is and send the apology letter to Mazu.

Hint: try to use git log and git checkout.